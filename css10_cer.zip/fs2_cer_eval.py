import whisper
from jiwer import cer
import os

# Load Whisper multilingual model
print("Loading Whisper model...")
model = whisper.load_model("base")

# Load reference texts (1 per line)
with open("css10_test_sentences.txt", "r", encoding="utf-8") as f:
    references = [line.strip() for line in f.readlines()]

# Transcribe FastSpeech2 outputs
cers = []
fs2_transcriptions = []

print("\nTranscribing FS2 .wav files...\n")

for i in range(1, 21):
    wav_path = f"/scratch/s6028608/FastSpeech2/css10_cer/Task1a/{i}.wav"
    print(f"Processing {wav_path}...")

    # Transcribe with Whisper
    result = model.transcribe(wav_path, language="fr")
    hypothesis = result["text"].strip()

    fs2_transcriptions.append(hypothesis)

    # Compute CER
    ref = references[i - 1]
    cer_score = cer(ref, hypothesis)
    cers.append(cer_score)

    print(f"Ref      : {ref}")
    print(f"Hypothesis: {hypothesis}")
    print(f"CER[{i}] = {cer_score:.3f}\n")

# Save results to file
with open("fs2_cers.txt", "w", encoding="utf-8") as out:
    for i, (ref, hyp, c) in enumerate(zip(references, fs2_transcriptions, cers), 1):
        out.write(f"[{i}] CER: {c:.3f}\nREF: {ref}\nHYP: {hyp}\n\n")

# Optional: save just CERs for plotting later
'''
with open("fs2_cers.txt", "w") as out:
    for c in cers:
        out.write(f"{c}\n")
'''

print("✅ All FS2 audio files transcribed.")
print(f"✅ Average CER: {sum(cers)/len(cers):.3f}")
