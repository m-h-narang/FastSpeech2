from scipy.stats import wilcoxon

# Load CER values, skipping empty lines
fs2 = [float(x.strip()) for x in open("fs2_cers.txt") if x.strip()]
tacotron2 = [float(x.strip()) for x in open("tacotron2_cers.txt") if x.strip()]
dctts = [float(x.strip()) for x in open("dctts_cers.txt") if x.strip()]

# Sanity check
print("Loaded CERs:")
print("FS2:", fs2[:20], "...")
print("Tacotron2:", tacotron2[:20], "...")
print("DCTTS:", dctts[:20], "...")

# Test 1: FS2 vs Tacotron2
stat1, p1 = wilcoxon(fs2, tacotron2)

# Test 2: FS2 vs DCTTS
stat2, p2 = wilcoxon(fs2, dctts)

print("\nWilcoxon Test Results:")
print(f"FastSpeech2 vs Tacotron2: statistic={stat1:.3f}, p-value={p1:.4f}")
print(f"FastSpeech2 vs DCTTS    : statistic={stat2:.3f}, p-value={p2:.4f}")
