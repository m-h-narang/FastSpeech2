""" Custom symbols for FastSpeech2 French training """

#from text import cmudict, pinyin

_pad = "_"
_punctuation = "!'(),.:;?«»–›‹*()0123456789[]-"
_special = "-"
#_letters     = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzàâäçéèêëîïôöùûüÿœæ"
_letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzàâäçéèêëîïôöùûüÿœæÉÀÇÈÙ’–"

_silences    = ["@sp", "@spn", "@sil"]

# Phoneme symbols
_french_phonemes = [
  '@a', '@b', '@d', '@e', '@f', '@g', '@i', '@j', '@k', '@l', '@m', '@mʲ',
  '@n', '@o', '@p', '@s', '@sil', '@spn', '@t', '@u', '@v', '@w', '@y', '@z',
  '@ø', '@œ', '@œʁ', '@œ̃', '@ɑ', '@ɑ̃', '@ɔ', '@ɔ̃', '@ə', '@ɛ', '@ɛ̃', '@ɡ',
  '@ɡ̃', '@ɥ', '@ɲ', '@ʁ', '@ʁ̃', '@ʃ', '@ʎ', '@ʒ', '@̃','@c','@c','@c', '@c', '@dʒ','@ɟ','@tʃ','@ts',
]
#_arpabet = ["@" + s for s in cmudict.valid_symbols]
#_pinyin = ["@" + s for s in pinyin.valid_symbols]

symbols = (
    [_pad]
    + list(_special)
    + list(_punctuation)
    + list(_letters)
    + _french_phonemes
    + _silences
)
