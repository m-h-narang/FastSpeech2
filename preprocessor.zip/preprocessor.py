# Save as preprocessor.py

import os
import random
import json
import tgt
import librosa
import numpy as np
import pyworld as pw
from tqdm import tqdm
from scipy.interpolate import interp1d
from sklearn.preprocessing import StandardScaler
import audio as Audio


class Preprocessor:
    def __init__(self, config):
        self.config = config
        self.in_dir = config["path"]["raw_path"]
        self.textgrid_dir = config["path"]["textgrid_path"]
        self.out_dir = config["path"]["preprocessed_path"]
        self.val_size = config["preprocessing"]["val_size"]
        self.sampling_rate = config["preprocessing"]["audio"]["sampling_rate"]
        self.hop_length = config["preprocessing"]["stft"]["hop_length"]

        self.pitch_phoneme_averaging = config["preprocessing"]["pitch"]["feature"] == "phoneme_level"
        self.energy_phoneme_averaging = config["preprocessing"]["energy"]["feature"] == "phoneme_level"
        self.pitch_normalization = config["preprocessing"]["pitch"]["normalization"]
        self.energy_normalization = config["preprocessing"]["energy"]["normalization"]

        self.STFT = Audio.stft.TacotronSTFT(
            config["preprocessing"]["stft"]["filter_length"],
            config["preprocessing"]["stft"]["hop_length"],
            config["preprocessing"]["stft"]["win_length"],
            config["preprocessing"]["mel"]["n_mel_channels"],
            self.sampling_rate,
            config["preprocessing"]["mel"]["mel_fmin"],
            config["preprocessing"]["mel"]["mel_fmax"]
        )

        os.makedirs(os.path.join(self.out_dir, "mel"), exist_ok=True)
        os.makedirs(os.path.join(self.out_dir, "pitch"), exist_ok=True)
        os.makedirs(os.path.join(self.out_dir, "energy"), exist_ok=True)
        os.makedirs(os.path.join(self.out_dir, "duration"), exist_ok=True)
        os.makedirs(os.path.join(self.out_dir, "logs"), exist_ok=True)
        self.error_log_path = os.path.join(self.out_dir, "logs", "preprocessing_errors.log")

    def build_from_path(self):
        print("Processing Data ...")
        out = []
        n_frames = 0
        pitch_scaler = StandardScaler()
        energy_scaler = StandardScaler()
        speakers = {}

        with open(self.error_log_path, "w") as error_log:
            for i, speaker in enumerate(tqdm(os.listdir(self.in_dir), desc="Speakers")):
                speakers[speaker] = i
                speaker_dir = os.path.join(self.in_dir, speaker)
                tg_speaker_dir = os.path.join(self.textgrid_dir, speaker)
                files = [f for f in os.listdir(speaker_dir) if f.endswith(".wav")]

                for wav_name in tqdm(files, desc=f"Processing {speaker}", leave=False):
                    basename = wav_name[:-4]
                    tg_path = os.path.join(tg_speaker_dir, f"{basename}.TextGrid")
                    if not os.path.exists(tg_path):
                        error_log.write(f"Missing TextGrid for {basename}\n")
                        continue
                    try:
                        result = self.process_utterance(speaker, basename, tg_path)
                        if result is None:
                            error_log.write(f"Skipping {basename}: process_utterance returned None\n")
                            continue

                        info, pitch, energy, num_frames = result
                        if len(pitch) != len(energy):
                            error_log.write(f"{basename} mismatch pitch-energy length\n")
                            continue

                        out.append(info)
                        pitch_scaler.partial_fit(pitch.reshape(-1, 1))
                        energy_scaler.partial_fit(energy.reshape(-1, 1))
                        n_frames += num_frames
                    except Exception as e:
                        error_log.write(f"Error processing {basename}: {e}\n")

        print("Computing statistic quantities ...")
        pitch_mean, pitch_std = self.get_stats(pitch_scaler)
        energy_mean, energy_std = self.get_stats(energy_scaler)

        pitch_min, pitch_max = self.normalize(os.path.join(self.out_dir, "pitch"), pitch_mean, pitch_std)
        energy_min, energy_max = self.normalize(os.path.join(self.out_dir, "energy"), energy_mean, energy_std)

        with open(os.path.join(self.out_dir, "speakers.json"), "w") as f:
            json.dump(speakers, f, indent=2)

        with open(os.path.join(self.out_dir, "stats.json"), "w") as f:
            json.dump({
                "pitch": [float(pitch_min), float(pitch_max), float(pitch_mean), float(pitch_std)],
                "energy": [float(energy_min), float(energy_max), float(energy_mean), float(energy_std)]
            }, f, indent=2)

        print(f"Total processed frames time: {n_frames * self.hop_length / self.sampling_rate / 3600:.2f} hours")

        random.shuffle(out)
        with open(os.path.join(self.out_dir, "train.txt"), "w") as f:
            f.writelines(line + "\n" for line in out[self.val_size:])
        with open(os.path.join(self.out_dir, "val.txt"), "w") as f:
            f.writelines(line + "\n" for line in out[:self.val_size])

        return out

    def process_utterance(self, speaker, basename, tg_path):
        wav_path = os.path.join(self.in_dir, speaker, f"{basename}.wav")
        text_path = os.path.join(self.in_dir, speaker, f"{basename}.lab")

        textgrid = tgt.io.read_textgrid(tg_path)
        phone, duration, start, end = self.get_alignment(textgrid.get_tier_by_name("phones"))
        if start >= end:
            return None

        wav, _ = librosa.load(wav_path, sr=self.sampling_rate)
        wav = wav[int(start * self.sampling_rate): int(end * self.sampling_rate)]
        if len(wav) == 0:
            return None

        with open(text_path, "r") as f:
            raw_text = f.readline().strip()
        text = "{" + " ".join(phone) + "}"

        pitch, t = pw.dio(wav.astype(np.float64), self.sampling_rate,
                          frame_period=self.hop_length / self.sampling_rate * 1000)
        pitch = pw.stonemask(wav.astype(np.float64), pitch, t, self.sampling_rate)

        mel_spectrogram, energy = Audio.tools.get_mel_from_wav(wav, self.STFT)

        total_duration = sum(duration)
        pitch = self.pad_or_trim(pitch, total_duration)
        energy = self.pad_or_trim(energy, total_duration)
        mel_spectrogram = mel_spectrogram[:, :total_duration]

        if self.pitch_phoneme_averaging:
            pitch = self.average_over_phonemes(pitch, duration)
        if self.energy_phoneme_averaging:
            energy = self.average_over_phonemes(energy, duration)

        pitch = pitch[:len(duration)]
        energy = energy[:len(duration)]

        np.save(os.path.join(self.out_dir, "duration", f"{speaker}-duration-{basename}.npy"), duration)
        np.save(os.path.join(self.out_dir, "pitch", f"{speaker}-pitch-{basename}.npy"), pitch)
        np.save(os.path.join(self.out_dir, "energy", f"{speaker}-energy-{basename}.npy"), energy)
        np.save(os.path.join(self.out_dir, "mel", f"{speaker}-mel-{basename}.npy"), mel_spectrogram.T)

        return "|".join([basename, speaker, text, raw_text]), self.remove_outlier(pitch), self.remove_outlier(energy), mel_spectrogram.shape[1]

    def get_alignment(self, tier):
        sil_phones = ["sil", "sp", "spn"]
        phones, durations = [], []
        start_time, end_time, end_idx = 0, 0, 0
        for t in tier._objects:
            s, e, p = t.start_time, t.end_time, t.text
            if not phones and p in sil_phones:
                continue
            if p not in sil_phones:
                phones.append(p)
                end_time = e
                end_idx = len(phones)
            else:
                phones.append(p)
            durations.append(int(np.round(e * self.sampling_rate / self.hop_length) -
                                 np.round(s * self.sampling_rate / self.hop_length)))
        return phones[:end_idx], durations[:end_idx], start_time, end_time

    def average_over_phonemes(self, values, durations):
        nonzero_ids = np.where(values != 0)[0]
        if len(nonzero_ids) < 2:
            return np.zeros(len(durations))
        interp_fn = interp1d(nonzero_ids, values[nonzero_ids],
                             fill_value=(values[nonzero_ids[0]], values[nonzero_ids[-1]]),
                             bounds_error=False)
        values = interp_fn(np.arange(len(values)))
        averaged = np.zeros(len(durations))
        pos = 0
        for i, d in enumerate(durations):
            averaged[i] = np.mean(values[pos: pos + d]) if d > 0 else 0
            pos += d
        return averaged

    def remove_outlier(self, values):
        values = np.array(values)
        p25 = np.percentile(values, 25)
        p75 = np.percentile(values, 75)
        iqr = p75 - p25
        mask = (values > (p25 - 1.5 * iqr)) & (values < (p75 + 1.5 * iqr))
        return values[mask] if np.any(mask) else values

    def normalize(self, in_dir, mean, std):
        max_val = float("-inf")
        min_val = float("inf")
        for file in os.listdir(in_dir):
            path = os.path.join(in_dir, file)
            arr = np.load(path)
            normed = (arr - mean) / std
            np.save(path, normed)
            max_val = max(max_val, np.max(normed))
            min_val = min(min_val, np.min(normed))
        return min_val, max_val

    def get_stats(self, scaler):
        if hasattr(scaler, "mean_") and hasattr(scaler, "scale_"):
            return scaler.mean_[0], scaler.scale_[0]
        return 0.0, 1.0

    def pad_or_trim(self, arr, target_len):
        if len(arr) < target_len:
            return np.concatenate([arr, np.zeros(target_len - len(arr))])
        return arr[:target_len]
